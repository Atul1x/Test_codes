package login.LoginDemo.POJO.request;

public class UserRequest {

	int Uid;
	String Uname;
	String Upwd;
	String GeneratedBy;

	public UserRequest() {
		// TODO Auto-generated constructor stub
		super();
	}

	public UserRequest(int uid, String uname, String upwd, String generatedBy) {
		super();
		Uid = uid;
		Uname = uname;
		Upwd = upwd;
		GeneratedBy = generatedBy;
	}

	public int getUid() {
		return Uid;
	}

	public void setUid(int uid) {
		Uid = uid;
	}

	public String getUname() {
		return Uname;
	}

	public void setUname(String uname) {
		Uname = uname;
	}

	public String getUpwd() {
		return Upwd;
	}

	public void setUpwd(String upwd) {
		Upwd = upwd;
	}

	public String getGeneratedBy() {
		return GeneratedBy;
	}

	public void setGeneratedBy(String generatedBy) {
		GeneratedBy = generatedBy;
	}

	@Override
	public String toString() {
		return "UserRequest [Uid=" + Uid + ", Uname=" + Uname + ", Upwd=" + Upwd + ", GeneratedBy=" + GeneratedBy + "]";
	}

}
