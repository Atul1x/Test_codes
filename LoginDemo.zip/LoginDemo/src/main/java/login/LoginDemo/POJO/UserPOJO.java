package login.LoginDemo.POJO;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "basicLoginz")
public class UserPOJO {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int Uid;
	
	@Column(name = "User_Name")
	String Uname;
	
	@Column (name = "User_Password")
	String Upwd;

	public UserPOJO(int uid, String uname, String upwd) {
		super();
		Uid = uid;
		Uname = uname;
		Upwd = upwd;
	}
	
	public UserPOJO() {
		// TODO Auto-generated constructor stub
	}

	public int getUid() {
		return Uid;
	}

	public void setUid(int uid) {
		Uid = uid;
	}

	public String getUname() {
		return Uname;
	}

	public void setUname(String uname) {
		Uname = uname;
	}

	public String getUpwd() {
		return Upwd;
	}

	public void setUpwd(String upwd) {
		Upwd = upwd;
	}

	@Override
	public String toString() {
		return "UserPOJO [Uid=" + Uid + ", Uname=" + Uname + ", Upwd=" + Upwd + "]";
	}

}
