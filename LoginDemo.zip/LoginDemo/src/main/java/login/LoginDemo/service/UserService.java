package login.LoginDemo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import login.LoginDemo.DAO.UserDAO;
import login.LoginDemo.POJO.UserPOJO;

@Service
public class UserService {

	@Autowired
	public UserDAO userDAO;

	public boolean SignIn(UserPOJO userPOJO) {
		// check if field value is empty or not
		if (userPOJO.getUname() == "" || userPOJO.getUpwd() == "") {
			return false;
		} else {
			UserPOJO databse_saveUserValue = userDAO.save(userPOJO);
			return true;
		}

	}

	public boolean emptyCheckLogin(UserPOJO userPOJO) {
		// check if field value is empty or not
		if (userPOJO.getUname() == "" || userPOJO.getUpwd() == "") {
			return false;
		} else {
			return true;
		}

	}

	public boolean validLogin(UserPOJO userPojo) {
		UserPOJO databse_userValue = userDAO.getUserName(userPojo.getUname());
		int db_uid = databse_userValue.getUid();
		String db_uname = databse_userValue.getUname();
		String db_upwd = databse_userValue.getUpwd();
		if (userPojo.getUid() == db_uid && userPojo.getUpwd().equalsIgnoreCase(db_upwd)) {
			return true;
		}
		return false;
	}

}
