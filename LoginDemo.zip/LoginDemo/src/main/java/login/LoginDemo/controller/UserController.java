package login.LoginDemo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import login.LoginDemo.POJO.UserPOJO;
import login.LoginDemo.service.UserService;

@RestController
public class UserController {

	@Autowired
	public UserService userService;

	@PostMapping("/signIn")
	public ResponseEntity<?> usersignIn(@RequestBody UserPOJO userPOJO) {
		if (userService.SignIn(userPOJO)) {
			return new ResponseEntity<>("user added successfully", HttpStatus.OK);
		} else {
			return new ResponseEntity<>("user failed to Sign in", HttpStatus.BAD_REQUEST);
		}
	}

	@PostMapping("/login")
	public ResponseEntity<?> userLogin(@RequestBody UserPOJO userPOJO) {
		if (userService.emptyCheckLogin(userPOJO)) {
			return new ResponseEntity<>("user found", HttpStatus.OK);
		} else {
			return new ResponseEntity<>("Oops !!! Enter valid crendentials", HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping("/details/{uid}")
	public ResponseEntity<?> getUserDetails(@PathVariable UserPOJO userPOJO) {
		if (userService.validLogin(userPOJO)) {
			return new ResponseEntity<>("user found", HttpStatus.OK);
		} else {
			return new ResponseEntity<>("Oops !!! user not found", HttpStatus.BAD_REQUEST);
		}
	}

}
