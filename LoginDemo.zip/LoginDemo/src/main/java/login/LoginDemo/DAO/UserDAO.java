package login.LoginDemo.DAO;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import login.LoginDemo.POJO.UserPOJO;

@Repository
public interface UserDAO extends JpaRepository<UserPOJO, Integer>{
	
		
	@Query(value = "SELECT * FROM basicLogin as u WHERE uid=:userName", nativeQuery=true)
	public UserPOJO getUserName(String userName);
	
}