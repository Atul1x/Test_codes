package Details.Student.Course.Request;


public class StudentRequest {

	int studentId;

	String studentFirstName;

	String studentLastName;

	String courseName;

	int marks;

	public StudentRequest() {
		super();
		// TODO Auto-generated constructor stub
	}

	public StudentRequest(int studentId, String studentFirstName, String studentLastName, String courseName,
			int marks) {
		super();
		this.studentId = studentId;
		this.studentFirstName = studentFirstName;
		this.studentLastName = studentLastName;
		this.courseName = courseName;
		this.marks = marks;
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getStudentFirstName() {
		return studentFirstName;
	}

	public void setStudentFirstName(String studentFirstName) {
		this.studentFirstName = studentFirstName;
	}

	public String getStudentLastName() {
		return studentLastName;
	}

	public void setStudentLastName(String studentLastName) {
		this.studentLastName = studentLastName;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public int getMarks() {
		return marks;
	}

	public void setMarks(int marks) {
		this.marks = marks;
	}

	@Override
	public String toString() {
		return "StudentRequest [studentId=" + studentId + ", studentFirstName=" + studentFirstName
				+ ", studentLastName=" + studentLastName + ", courseName=" + courseName + ", marks=" + marks + "]";
	}

}
