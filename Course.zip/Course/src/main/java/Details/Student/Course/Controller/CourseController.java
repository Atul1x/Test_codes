package Details.Student.Course.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import Details.Student.Course.Entity.Course;
import Details.Student.Course.Response.StudentResponse;
import Details.Student.Course.Service.CourseService;

@RestController
public class CourseController {

	@Autowired
	CourseService courseService;

	@PostMapping("/save")
	public StudentResponse saveAllReponse(@RequestBody Course courseEntity) {
		StudentResponse studentResponse = new StudentResponse();
		studentResponse = courseService.saveAllReponse(courseEntity);
		return studentResponse;
	}
}
