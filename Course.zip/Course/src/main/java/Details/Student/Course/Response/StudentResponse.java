package Details.Student.Course.Response;

import com.fasterxml.jackson.annotation.JsonProperty;

public class StudentResponse {

	@JsonProperty("statusCode")
	private String statusCode;

	@JsonProperty("statusDescription")
	private String statusDescription;

	@JsonProperty("result")
	private double result;

	public StudentResponse() {
		super();
		// TODO Auto-generated constructor stub
	}

	public StudentResponse(String statusCode, String statusDescription, double result) {
		super();
		this.statusCode = statusCode;
		this.statusDescription = statusDescription;
		this.result = result;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusDescription() {
		return statusDescription;
	}

	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}

	public double getResult() {
		return result;
	}

	public void setResult(double result) {
		this.result = result;
	}

	@Override
	public String toString() {
		return "StudentResponse [statusCode=" + statusCode + ", statusDescription=" + statusDescription + ", result="
				+ result + "]";
	}

}
