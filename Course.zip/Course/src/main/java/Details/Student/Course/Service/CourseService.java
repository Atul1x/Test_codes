package Details.Student.Course.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Details.Student.Course.Entity.Course;
import Details.Student.Course.Repository.CourseRepository;
import Details.Student.Course.Request.StudentRequest;
import Details.Student.Course.Response.StudentResponse;

@Service
public class CourseService {

	@Autowired
	public CourseRepository courseRepository;

	public StudentResponse saveAllReponse(Course course) {

		StudentResponse studentResponse = new StudentResponse();
		StudentRequest studentRequest = new StudentRequest();

		if (course.equals(null)) {
			studentResponse.setStatusCode("-101");
			studentResponse.setStatusDescription("INTERNAL SERVER ERROR OR FAILED TO SAVE");
		}

		else {
			studentRequest.setStudentId(studentRequest.getStudentId());
			studentRequest.setStudentFirstName(studentRequest.getStudentFirstName());
			studentRequest.setStudentLastName(studentRequest.getStudentLastName());
			studentRequest.setCourseName(studentRequest.getCourseName());
			studentRequest.setMarks(studentRequest.getMarks());
			
			courseRepository.save(course);
		}

		return studentResponse;
	}

}
